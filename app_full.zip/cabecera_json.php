<header>
 <span id="cab_usuario"></span>	
 <a href="#" onclick="cargarCategorias();">Home</a>
 <a href="#" onclick="cargarCarrito();">Carrito</a>
 <a href="#" onclick="cerrarSesionUnaPagina();">Cerrar sesión</a>
</header>
<hr>